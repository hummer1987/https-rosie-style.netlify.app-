import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const allowedOrigins = (process.env.FRONTEND_ORIGIN || "").split(",").map(x => x.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) return cb(null, true);
    return cb(new Error("Този адрес няма разрешение да използва AI сървъра."));
  }
}));
app.use(express.json({ limit: "8mb" }));

const PORT = process.env.PORT || 8787;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

function parseImageData(dataUrl) {
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/.exec(dataUrl || "");
  if (!match) throw new Error("Снимката не е във валиден формат.");
  return { mimeType: match[1], data: match[2] };
}

async function askGemini(systemInstruction, parts, json = true) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("Липсва GEMINI_API_KEY в настройките на AI сървъра.");
  const response = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemInstruction }] },
      contents: [{ role: "user", parts }],
      generationConfig: {
        temperature: 0.75,
        responseMimeType: json ? "application/json" : "text/plain",
        maxOutputTokens: 3000
      }
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const msg = data?.error?.message || "Gemini API върна грешка.";
    if (response.status === 400 || response.status === 403) throw new Error(`Gemini отказа заявката: ${msg}`);
    if (response.status === 429) throw new Error("Достигнат е временният безплатен лимит на Gemini. Изчакайте малко и опитайте отново.");
    throw new Error(msg);
  }
  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
  if (!text) throw new Error("Gemini не върна разпознаваем резултат. Опитай отново.");
  return text;
}

function jsonFrom(text) {
  const clean = text.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  return JSON.parse(start >= 0 && end >= start ? clean.slice(start, end + 1) : clean);
}

app.get("/api/health", (_, res) => res.json({ ok: true, aiConfigured: Boolean(process.env.GEMINI_API_KEY), provider: "Google Gemini", model: MODEL }));

app.post("/api/analyze-item", async (req, res) => {
  try {
    const { imageData } = req.body || {};
    const image = parseImageData(imageData);
    const result = await askGemini(
      "Ти си експерт по каталогизиране на детски дрехи и аксесоари. Разглеждаш само предмета, не правиш изводи за човека. Отговори само с валиден JSON на български със структура: {name,category,subcategory,color,secondaryColors,season,weather,pattern,material,style,tags}. category е едно от: Горнища, Долнища, Рокли и гащеризони, Връхни дрехи, Обувки, Чанти, Аксесоари. Не измисляй марка или състав. Ако нещо не се вижда, използвай празен низ или масив. season е масив от подходящите сезони.",
      [{ text: "Опиши дрехата или аксесоара на снимката за личен дигитален гардероб." }, { inline_data: { mime_type: image.mimeType, data: image.data } }]
    );
    res.json(jsonFrom(result));
  } catch (e) {
    res.status(500).json({ error: e.message || "Неуспешно разпознаване на снимката." });
  }
});

app.post("/api/style-outfit", async (req, res) => {
  try {
    const { items, preferences, weather } = req.body || {};
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "Добавете дрехи в гардероба." });
    const wardrobe = items.map(({ id, name, category, color, season, style, tags }) => ({ id, name, category, color, season, style, tags }));
    const result = await askGemini(
      "Ти си внимателен, позитивен стилист за момиче на 11 години. Предлагай удобни, подходящи за възрастта, практични и ненатрапчиви визии. Не коментирай тяло, тегло, външност или привлекателност. Използвай наличните артикули от гардероба, като посочваш точните им id. Не предлагай покупки и не измисляй id. ВАЖНО: освен наличните дрехи, предложи за всяка визия 1-3 идеи за допълващи се дрехи или аксесоари, които не е задължително да са записани в гардероба (например шнола, лента за коса, обеци, гривна, колан, шал, чорапи, раница, чанта, шапка). Формулирай ги като „ако имаш подобно“, без натиск за покупка. Върни само JSON със структура: {outfits:[{title,description,items:[{id,role}],palette:[цветове],accessories:[текст],suggestedExtras:[{name,category,reason}],why,weatherNote,alternatives:[текст]}]}. Направи точно 3 различни предложения, ако наличните дрехи позволяват; иначе толкова, колкото са възможни. suggestedExtras трябва да е масив с 1-3 конкретни идеи за всяка визия. Не използвай несъществуващи id.",
      [{ text: JSON.stringify({ wardrobe, preferences, weather }) }]
    );
    const parsed = jsonFrom(result);
    if (!Array.isArray(parsed.outfits)) throw new Error("Gemini върна неочакван формат на визиите.");
    parsed.outfits = parsed.outfits.map(o => ({ ...o, suggestedExtras: Array.isArray(o.suggestedExtras) ? o.suggestedExtras : [] }));
    res.json(parsed);
  } catch (e) {
    res.status(500).json({ error: e.message || "Неуспешно генериране на визии." });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`MyStyle AI Gemini API listening on port ${PORT}`));
