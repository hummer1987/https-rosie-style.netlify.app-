# MyStyle AI – версия 1.2 (Роузи)

PWA приложение за личен дигитален гардероб и AI стилист. Версията използва Google Gemini API вместо OpenAI.

## Ново във версия 1.2
- AI сървърът използва Google Gemini API (`gemini-2.5-flash`).
- При добавяне на дреха има отделни бутони **Камера** и **Галерия**; изборът от галерията не налага камера.
- Началният екран показва различно мило послание от колекция на Роузи; при повторно избиране на „Начало“ се сменя поздравът.
- Всяка предложена визия включва идеи за 1–3 допълнителни аксесоара или дрехи извън записания гардероб. Те са идеи „ако имаш подобно“, а не препоръки за задължителни покупки.
- Нова иконка с розовия аксолотъл Роузи.
- Запазени са IndexedDB и автоматичната миграция от стария localStorage.

## Публикуване на frontend в Netlify
Използвай същия Netlify сайт и същия GitHub repository, който вече е свързан с него. Качи съдържанието на тази папка в root на repository-то.

Настройки:
- Build command: `npm run build`
- Publish directory: `dist`
- Base directory: празно

`netlify.toml` съдържа тези настройки. След качването избери в Netlify **Deploys → Trigger deploy → Clear cache and deploy site**.

## Публикуване на AI сървъра в Render
`render.yaml` е конфигуриран за Render Blueprint и задава:
- root directory: `server`
- build command: `npm install`
- start command: `npm start`
- health check: `/api/health`

В Render добави секретната environment variable:
- `GEMINI_API_KEY` = API ключът от Google AI Studio (не го добавяй в GitHub, Netlify frontend или този архив).

Другите настройки са зададени в `render.yaml`:
- `GEMINI_MODEL=gemini-2.5-flash`
- `FRONTEND_ORIGIN=https://legendary-sawine-ef6877.netlify.app`

След публикуването провери `https://АДРЕСЪТ-ОТ-RENDER/api/health`. Очаква се JSON с `ok: true`, `aiConfigured: true`, `provider: "Google Gemini"`.

В приложението отвори Настройки и постави само базовия HTTPS адрес на Render сървъра, без `/api/health`.

## Локално стартиране
Изисква Node.js 20+.

1. В root: `npm install`
2. В `server`: `npm install`
3. Копирай `.env.example` в `.env` в root и попълни `GEMINI_API_KEY`.
4. Стартирай API сървъра: `cd server` и `npm start`.
5. В отделен терминал от root: `npm run dev`.
6. В настройките на приложението използвай `http://localhost:8787`.

## Поверителност
Безплатното ниво на Gemini API може да използва входящите данни и отговорите за подобряване на услугите си и за човешки преглед съгласно условията на Google. Не изпращайте чувствителни лични данни или снимки на хора. За това приложение снимайте само дрехите и аксесоарите. API ключът трябва да се пази само като secret в Render.

## Съхранение
Гардеробът се съхранява локално в IndexedDB на устройството. Не изчиствайте данните на браузъра при обновяване. Направете резервен архив през Настройки преди големи промени.
