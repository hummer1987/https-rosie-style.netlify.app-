import { useEffect, useMemo, useRef, useState } from "react";
import { Camera, Shirt, Sparkles, CloudSun, Heart, CalendarDays, Settings, Plus, Search, Trash2, Download, Upload, WandSparkles, Check, X, ChevronDown, Footprints, Palette, RefreshCw, Archive, Sun, CloudRain, Wind, SlidersHorizontal, Info, Star } from "lucide-react";

type Item={id:string;name:string;category:string;subcategory?:string;color:string;secondaryColors?:string[];season:string[];weather?:string;pattern?:string;material?:string;style?:string;tags?:string[];image:string;created:number;archived?:boolean;wears?:number};
type Outfit={title:string;description:string;items:{id:string;role:string}[];palette:string[];accessories:string[];suggestedExtras?:{name:string;reason:string;category?:string}[];why:string;weatherNote:string;alternatives:string[]};
const KEY="mystyle-v1-data";
const categories=["Всички","Горнища","Долнища","Рокли и гащеризони","Връхни дрехи","Обувки","Чанти","Аксесоари"];
const seasons=["Пролет","Лято","Есен","Зима","Целогодишно"];
const styles=["Ежедневен","Спортен","Streetwear","Елегантен","Училищен","Романтичен","Цветен","Минималистичен","Уютен"];
const uid=()=>Math.random().toString(36).slice(2,10);
const greetings=[
 "Днес е чудесен ден да бъдеш себе си! 💗", "Нека денят ти започне с усмивка и щипка блясък! ✨", "Твоята усмивка е най-хубавият аксесоар! 🌸", "Готова ли си да направиш деня си цветен? 🌈", "Малко настроение, много стил и голяма усмивка! 💕",
 "Днес светът е твоят подиум – върви смело! 👑", "Най-хубавата визия е тази, в която се чувстваш чудесно! 💖", "Избери си цвят и нека денят заблести! 🎀", "Време е за ново модно приключение! 🦋", "Нека днес има повече смях и любими дрехи! 🌷",
 "Ти носиш магията – дрехите само я допълват! ✨", "Една малка идея може да направи деня специален! 💫", "Днес е идеален ден да експериментираш! 🎨", "Роузи ти изпраща розова прегръдка! 🩷", "Бъди смела, бъди нежна, бъди себе си! 🌺",
 "Нека стилът ти разказва най-хубавата история! 📖", "Усмихни се – очакват те хубави неща! ☀️", "Днес добави щипка цвят към приключенията си! 🌈", "Ти си уникална – и стилът ти може да бъде такъв! 💎", "Модното настроение започва оттук! 💗",
 "Нека денят ти е мек като любимия суичър и ярък като любимия цвят! 🧁", "Всяка дреха има история. Каква ще бъде днешната? 👗", "Днес избери нещо, което те кара да танцуваш! 💃", "Понякога най-добрият план е да бъдеш себе си! 🌼", "Роузи е готова за нова стилна мисия! 🐾",
 "Нека днес съберем удобство, цвят и щастие в една визия! 💞", "Твоят гардероб крие още куп чудесни идеи! 🎁", "Малко розово настроение никога не е излишно! 🌸", "Днес можеш да бъдеш толкова цветна, колкото поискаш! 🦄", "Време е да открием любимата ти комбинация! 🪄",
 "Носи това, което ти носи радост! 💖", "Нека денят ти бъде пълен с приятни изненади! 🎀", "Една усмивка ти отива с всичко! 😊", "Днес е нова страница за твоя стил! 📚", "Роузи вярва, че ще изглеждаш страхотно и ще се чувстваш още по-добре! 🩷"
];
const DB_NAME="mystyle-ai-db", DB_STORE="app", DB_KEY="main";
const openDB=()=>new Promise<IDBDatabase>((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(DB_STORE))req.result.createObjectStore(DB_STORE)};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error("Не може да се отвори локалната база данни."));});
const dbGet=async()=>{const db=await openDB();return new Promise<any>((resolve,reject)=>{const tx=db.transaction(DB_STORE,"readonly"),req=tx.objectStore(DB_STORE).get(DB_KEY);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});};
const dbSet=async(value:any)=>{const db=await openDB();return new Promise<void>((resolve,reject)=>{const tx=db.transaction(DB_STORE,"readwrite");tx.objectStore(DB_STORE).put(value,DB_KEY);tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error||new Error("Неуспешно записване."))};tx.onabort=()=>{db.close();reject(tx.error||new Error("Записването беше прекъснато."))};});};
const readLegacy=()=>{try{return JSON.parse(localStorage.getItem(KEY)||"{}")}catch{return {}}};
const fileData=async(f:File)=>{const data=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(new Error("Снимката не може да бъде прочетена."));r.readAsDataURL(f)});return new Promise<string>((resolve,reject)=>{const img=new Image();img.onload=()=>{try{const max=1400,scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext("2d");if(!ctx)throw new Error("Не може да се обработи снимката.");ctx.drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL("image/jpeg",0.78));}catch(e){reject(e)}};img.onerror=()=>reject(new Error("Файлът не е валидна снимка."));img.src=data;});};
function App(){
 const [items,setItems]=useState<Item[]>([]);
 const [saved,setSaved]=useState<{id:string;date:string;outfit:Outfit}[]>([]);
 const [storageReady,setStorageReady]=useState(false);
 const [tab,setTab]=useState("home");
 const [filter,setFilter]=useState("Всички");
 const [query,setQuery]=useState("");
 const [showAdd,setShowAdd]=useState(false);
 const [editing,setEditing]=useState<Item|null>(null);
 const [photo,setPhoto]=useState("");
 const [form,setForm]=useState<any>({name:"",category:"Горнища",color:"",season:["Пролет","Есен"],style:"Ежедневен"});
 const [busy,setBusy]=useState(false);
 const [message,setMessage]=useState("");
 const [outfits,setOutfits]=useState<Outfit[]>([]);
 const [prefs,setPrefs]=useState<any>({occasion:"Училище",style:"Ежедневен",mood:"Свежо и цветно",avoid:"",must:"",noRepeat:true});
 const [weather,setWeather]=useState<any>({city:"София",temp:15,condition:"Променлива облачност",wind:10,rain:0});
 const [weatherAuto,setWeatherAuto]=useState(false);
 const [apiUrl,setApiUrl]=useState(localStorage.getItem("mystyle-api")||"");
 const [showSettings,setShowSettings]=useState(false);
 const [calendarDate,setCalendarDate]=useState(new Date().toISOString().slice(0,10));
 const [greeting,setGreeting]=useState(()=>greetings[Math.floor(Math.random()*greetings.length)]);
 const galleryRef=useRef<HTMLInputElement>(null);
 const cameraRef=useRef<HTMLInputElement>(null);
 useEffect(()=>{let alive=true;(async()=>{try{let data=await dbGet();if(!data){data=readLegacy();if((data.items||[]).length||(data.saved||[]).length){await dbSet(data);try{localStorage.removeItem(KEY)}catch{}}}if(alive){setItems(data?.items||[]);setSaved(data?.saved||[]);}}catch(e){if(alive)setMessage("Проблем с локалната база данни. Обнови страницата и опитай отново.");}finally{if(alive)setStorageReady(true)}})();return()=>{alive=false}},[]);
 useEffect(()=>{if(!storageReady)return;dbSet({items,saved,version:2}).catch(()=>setMessage("Не успях да запазя промените. Провери свободното място в телефона."));},[items,saved,storageReady]);
 useEffect(()=>{if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});},[]);
 const active=items.filter(i=>!i.archived);
 const filtered=useMemo(()=>active.filter(i=>(filter==="Всички"||i.category===filter)&&(`${i.name} ${i.color} ${(i.tags||[]).join(" ")}`).toLowerCase().includes(query.toLowerCase())),[active,filter,query]);
 const api=(path:string)=>`${apiUrl.replace(/\/$/,"")}${path}`;
 const updateForm=(k:string,v:any)=>setForm((p:any)=>({...p,[k]:v}));
 async function addPhoto(file?:File){if(!file)return;try{const data=await fileData(file);setPhoto(data);setMessage("Снимката е обработена и добавена. Можеш да попълниш данните или да използваш AI разпознаване.");}catch(e:any){setMessage(e?.message||"Неуспешно зареждане на снимката.")}}
 async function analyze(){
   if(!photo)return setMessage("Първо добави снимка.");
   setBusy(true);setMessage("AI разглежда дрехата…");
   try{const r=await fetch(api("/api/analyze-item"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({imageData:photo})});const d=await r.json();if(!r.ok)throw Error(d.error);
     setForm((p:any)=>({...p,...d,season:Array.isArray(d.season)?d.season:[d.season||"Целогодишно"],secondaryColors:d.secondaryColors||[],tags:d.tags||[]}));setMessage("Готово! Провери описанието и запази.");}
   catch(e:any){setMessage(e.message+" Можеш да въведеш данните ръчно.");}finally{setBusy(false);}
 }
 function saveItem(){
   if(!storageReady)return setMessage("Приложението още подготвя гардероба. Изчакай момент.");
   if(!form.name||!photo)return setMessage("Добави снимка и име на артикула.");
   const obj:Item={...form,id:editing?.id||uid(),image:photo,created:editing?.created||Date.now(),season:Array.isArray(form.season)?form.season:[form.season||"Целогодишно"],wears:editing?.wears||0};
   setItems(p=>editing?p.map(x=>x.id===obj.id?obj:x):[obj,...p]);setShowAdd(false);setEditing(null);setPhoto("");setForm({name:"",category:"Горнища",color:"",season:["Пролет","Есен"],style:"Ежедневен"});setMessage("Добавено в гардероба!");
 }
 function editItem(item:Item){setEditing(item);setPhoto(item.image);setForm({...item});setShowAdd(true);}
 async function getWeather(){
  setBusy(true);
  try{
   let lat=42.6977,lon=23.3219;
   if(weatherAuto&&navigator.geolocation){const pos=await new Promise<GeolocationPosition>((ok,no)=>navigator.geolocation.getCurrentPosition(ok,no,{timeout:8000}));lat=pos.coords.latitude;lon=pos.coords.longitude;}
   const r=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,precipitation,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto`);
   const d=await r.json();const code=d.current.weather_code;const desc=code===0?"Слънчево":code<4?"Променлива облачност":code<70?"Дъжд или ръмеж":code<80?"Сняг":"Валежи";
   setWeather({city:weatherAuto?"Текущо местоположение":weather.city,temp:Math.round(d.current.temperature_2m),condition:desc,wind:Math.round(d.current.wind_speed_10m),rain:Math.round(d.daily.precipitation_probability_max?.[0]||0),min:Math.round(d.daily.temperature_2m_min?.[0]),max:Math.round(d.daily.temperature_2m_max?.[0])});
   setMessage("Прогнозата е обновена.");
  }catch(e:any){setMessage("Не успях да заредя времето. Провери интернет връзката и разрешенията за местоположение.");}finally{setBusy(false);}
 }
 async function makeLooks(){
  if(!active.length)return setMessage("Добави поне няколко дрехи в гардероба.");
  setBusy(true);setMessage("Стилистът подбира комбинации…");
  try{
   const r=await fetch(api("/api/style-outfit"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:active,preferences:prefs,weather})});
   const d=await r.json();if(!r.ok)throw Error(d.error);setOutfits(d.outfits||[]);setTab("looks");setMessage("Твоите предложения са готови!");
  }catch(e:any){
   const picks=active.filter(i=>!prefs.avoid.toLowerCase().includes(i.category.toLowerCase()));
   const groups=["Горнища","Долнища","Обувки","Връхни дрехи","Аксесоари"];
   const chosen=groups.map(c=>picks.find(i=>i.category===c)).filter(Boolean) as Item[];
   if(chosen.length>=2){setOutfits([{title:"Моята визия",description:"Комбинация от наличния ти гардероб.",items:chosen.map(i=>({id:i.id,role:i.category})),palette:chosen.map(i=>i.color).filter(Boolean),accessories:[],why:"Използваме дрехите, които вече имаш. AI стилистът ще даде по-подробни идеи след настройване на връзката.",weatherNote:`Днес: ${weather.temp}°C, ${weather.condition}.`,alternatives:[],suggestedExtras:[]}]);setTab("looks");setMessage("Показана е базова комбинация. "+e.message);}
   else setMessage(e.message+" Провери настройките на AI сървъра.");
  }finally{setBusy(false);}
 }
 function saveLook(o:Outfit){setSaved(p=>[{id:uid(),date:new Date().toISOString().slice(0,10),outfit:o},...p]);setMessage("Визията е запазена в любимите!");}
 function exportData(){const blob=new Blob([JSON.stringify({items,saved,version:1},null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="mystyle-backup.json";a.click();URL.revokeObjectURL(a.href);}
 async function importData(file?:File){if(!file)return;try{const d=JSON.parse(await file.text());if(!Array.isArray(d.items))throw Error();setItems(d.items);setSaved(d.saved||[]);setMessage("Архивът е възстановен.");}catch{setMessage("Файлът не е валиден архив на MyStyle AI.");}}
 const itemById=(id:string)=>items.find(i=>i.id===id);
 const nav=[["home","Начало",Sparkles],["wardrobe","Гардероб",Shirt],["create","Стилист",WandSparkles],["looks","Визии",Heart],["calendar","Календар",CalendarDays]];
 return <div className="app">
  <header className="top"><div className="brand"><img className="logo-img" src="/icon.png" alt="Роузи"/><div><b>MyStyle <span>AI</span></b><small>твоят личен стилист</small></div></div><button className="iconbtn" onClick={()=>setShowSettings(true)} aria-label="Настройки"><Settings/></button></header>
  {message&&<div className="toast" onClick={()=>setMessage("")}>{message}<X size={15}/></div>}
  <main>
   {tab==="home"&&<section className="page">
    <div className="hello"><div><p className="eyebrow">ТВОЯТ СТИЛ, ТВОИТЕ ПРАВИЛА</p><h1>Здравей, <span>стилна!</span> ✨</h1><p>Какво ще облечем днес?</p><div className="greeting-note">{greeting}</div></div><div className="sparkle">✦</div></div>
    <div className="weather-card"><div className="weather-icon"><CloudSun size={30}/></div><div className="weather-info"><b>{weather.temp}°C · {weather.condition}</b><span>{weather.city} · Вятър {weather.wind} km/h · Валежи {weather.rain}%</span>{weather.min!==undefined&&<small>Днес: {weather.min}° – {weather.max}°</small>}</div><button className="round" onClick={getWeather} disabled={busy}><RefreshCw size={17}/></button></div>
    <div className="section-head"><h2>Какво ти се прави?</h2></div>
    <div className="action-grid">
      <button className="action-card pink" onClick={()=>setTab("create")}><div className="action-icon"><WandSparkles/></div><b>Избери ми визия</b><small>AI стилистът ще помогне</small><span>→</span></button>
      <button className="action-card lilac" onClick={()=>{setShowAdd(true);setEditing(null);setPhoto("");}}><div className="action-icon"><Camera/></div><b>Добави дреха</b><small>Снимай или избери снимка</small><span>→</span></button>
    </div>
    <div className="stats"><div><b>{active.length}</b><span>дрехи в гардероба</span></div><div><b>{saved.length}</b><span>любими визии</span></div><div><b>{new Set(active.map(i=>i.category)).size}</b><span>категории</span></div></div>
    <div className="section-head"><h2>Последни добавени</h2><button className="textbtn" onClick={()=>setTab("wardrobe")}>Виж всички</button></div>
    <div className="mini-grid">{active.slice(0,4).map(i=><div className="mini-item" key={i.id} onClick={()=>editItem(i)}><img src={i.image}/><b>{i.name}</b><small>{i.color}</small></div>)}{!active.length&&<div className="empty">Гардеробът ти те очаква! Добави първата си дреха. 💗</div>}</div>
   </section>}
   {tab==="wardrobe"&&<section className="page"><div className="page-title"><div><p className="eyebrow">ВСИЧКО, КОЕТО ОБИЧАШ ДА НОСИШ</p><h1>Моят гардероб 👗</h1></div><button className="primary small" onClick={()=>{setEditing(null);setPhoto("");setShowAdd(true)}}><Plus size={17}/> Добави</button></div>
    <div className="search"><Search size={18}/><input placeholder="Търси дреха или цвят…" value={query} onChange={e=>setQuery(e.target.value)}/></div>
    <div className="chips">{categories.map(c=><button key={c} className={filter===c?"chip active":"chip"} onClick={()=>setFilter(c)}>{c}</button>)}</div>
    <div className="wardrobe-grid">{filtered.map(i=><div className="item-card" key={i.id}><img src={i.image} onClick={()=>editItem(i)}/><div className="item-meta"><b>{i.name}</b><span>{i.color} · {i.category}</span><div className="item-actions"><button onClick={()=>editItem(i)}>Редактирай</button><button onClick={()=>setItems(p=>p.map(x=>x.id===i.id?{...x,archived:true}:x))}>Архив</button></div></div></div>)}</div>
    {!filtered.length&&<div className="empty">Няма намерени дрехи в тази категория.</div>}
   </section>}
   {tab==="create"&&<section className="page"><p className="eyebrow">ТВОЯТ AI СТИЛИСТ</p><h1>Създай ми визия ✨</h1><p className="sub">Кажи какво ти харесва и ще подберем комбинация от твоя гардероб.</p>
    <div className="form-card"><label>За какъв повод?</label><div className="chips">{["Училище","Разходка","Рожден ден","Спорт","Семейно събитие","У дома"].map(x=><button className={prefs.occasion===x?"chip active":"chip"} onClick={()=>setPrefs({...prefs,occasion:x})}>{x}</button>)}</div>
    <label>Какъв стил ти харесва?</label><div className="chips">{styles.map(x=><button className={prefs.style===x?"chip active":"chip"} onClick={()=>setPrefs({...prefs,style:x})}>{x}</button>)}</div>
    <label>Какво настроение?</label><select value={prefs.mood} onChange={e=>setPrefs({...prefs,mood:e.target.value})}><option>Свежо и цветно</option><option>Спокойно и нежно</option><option>Смело и различно</option><option>Уютно и удобно</option><option>Изненадай ме</option></select>
    <label>Има ли нещо, което не искаш да носиш?</label><input value={prefs.avoid} onChange={e=>setPrefs({...prefs,avoid:e.target.value})} placeholder="Например: рокли, дънки…"/>
    <label>Искаш ли задължително да включим нещо?</label><input value={prefs.must} onChange={e=>setPrefs({...prefs,must:e.target.value})} placeholder="Например: любимата ми розова блуза"/>
    <label>Времето</label><div className="weather-inline"><span>🌡️ {weather.temp}°C · {weather.condition}</span><button className="textbtn" onClick={getWeather}>Обнови</button></div>
    <label className="checkline"><input type="checkbox" checked={prefs.noRepeat} onChange={e=>setPrefs({...prefs,noRepeat:e.target.checked})}/> Избягвай наскоро носени комбинации</label>
    <button className="primary full" onClick={makeLooks} disabled={busy||!active.length}><Sparkles size={18}/>{busy?"Подготвям предложения…":"Предложи ми 3 визии"}</button>
    {!active.length&&<small className="hint">Първо добави дрехи в гардероба.</small>}
    </div>
   </section>}
   {tab==="looks"&&<section className="page"><p className="eyebrow">ПОДБРАНО СПЕЦИАЛНО ЗА ТЕБ</p><h1>Твоите визии 💖</h1>{outfits.map((o,n)=><div className="look-card" key={n}><div className="look-head"><div><span className="look-num">ВИЗИЯ {n+1}</span><h2>{o.title}</h2></div><button className="heart" onClick={()=>saveLook(o)}><Heart/></button></div><p>{o.description}</p><div className="look-items">{o.items.map(x=>{const i=itemById(x.id);return i?<div className="look-item" key={x.id}><img src={i.image}/><span>{i.name}<small>{x.role}</small></span></div>:null})}</div>
      {!!o.palette?.length&&<div className="palette"><b><Palette size={15}/> Цветова комбинация</b><div>{o.palette.map((c,i)=><span key={i} title={c} style={{background:/^#/.test(c)?c:undefined}}>{/^#/.test(c)?"":c}</span>)}</div></div>}
      {!!o.accessories?.length&&<p className="tip"><Star size={16}/> <b>Аксесоари:</b> {o.accessories.join(", ")}</p>}
      {!!o.suggestedExtras?.length&&<div className="extra-ideas"><div className="extra-title"><Sparkles size={17}/><b>Малко допълнение от Роузи</b></div><p className="muted">Идеи за аксесоари или дрехи, които не е нужно да добавяш в дигиталния гардероб – просто провери дали имаш нещо подобно.</p>{o.suggestedExtras.map((x,i)=><div className="extra-row" key={i}><span className="extra-emoji">{x.category?.toLowerCase().includes("бижу")||x.name.toLowerCase().includes("обица")?"💎":x.name.toLowerCase().includes("чанта")?"👜":x.name.toLowerCase().includes("шапка")?"🧢":"🎀"}</span><span><b>{x.name}</b><small>{x.reason}</small></span></div>)}</div>}
      <p className="tip"><Sparkles size={16}/> {o.why}</p><p className="tip"><CloudSun size={16}/> {o.weatherNote}</p>
      {!!o.alternatives?.length&&<p className="muted">Други идеи: {o.alternatives.join(" · ")}</p>}
      <button className="outline full" onClick={()=>saveLook(o)}><Heart size={16}/> Запази в любимите</button></div>)}
      {!outfits.length&&<div className="empty">Още нямаш предложения. Отиди в „Стилист“ и създай първата си визия! ✨<button className="primary" onClick={()=>setTab("create")}>Към стилиста</button></div>}
      <h2 className="subhead">Любими визии</h2>{saved.map(s=><div className="saved-row" key={s.id}><div><b>{s.outfit.title}</b><small>{s.date}</small></div><button onClick={()=>setSaved(p=>p.filter(x=>x.id!==s.id))}><Trash2 size={17}/></button></div>)}
   </section>}
   {tab==="calendar"&&<section className="page"><p className="eyebrow">ПЛАНИРАЙ СВОЯ СТИЛ</p><h1>Календар 📅</h1><div className="form-card"><label>Избери дата</label><input type="date" value={calendarDate} onChange={e=>setCalendarDate(e.target.value)}/><p className="sub">Запазените визии са подредени по дата. Запазването на нова визия я добавя към любимите за днешния ден.</p></div>{saved.filter(s=>s.date===calendarDate).map(s=><div className="saved-row"><b>{s.outfit.title}</b><span>{s.outfit.items.length} артикула</span></div>)}{!saved.some(s=>s.date===calendarDate)&&<div className="empty">Няма запазени визии за тази дата.</div>}<div className="section-head"><h2>Всички запазени</h2></div>{saved.map(s=><div className="saved-row" key={s.id}><div><b>{s.outfit.title}</b><small>{s.date}</small></div><span>{s.outfit.items.length} артикула</span></div>)}</section>}
  </main>
  <nav className="bottom-nav">{nav.map(([id,label,Icon]:any)=><button className={tab===id?"selected":""} onClick={()=>{if(id==="home")setGreeting(greetings[Math.floor(Math.random()*greetings.length)]);setTab(id)}} key={id}><Icon size={21}/><span>{label}</span></button>)}</nav>

  {showAdd&&<div className="modal-back" onClick={()=>setShowAdd(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><h2>{editing?"Редактирай дреха":"Добави в гардероба"}</h2><button className="iconbtn" onClick={()=>setShowAdd(false)}><X/></button></div>
    <div className="photo-box" onClick={()=>galleryRef.current?.click()}>{photo?<img src={photo}/>:<><Camera size={32}/><b>Добави снимка</b><small>Избери от галерията или направи нова снимка</small></>}</div>
    <div className="photo-actions"><button className="outline" onClick={()=>cameraRef.current?.click()}><Camera size={17}/> Камера</button><button className="outline" onClick={()=>galleryRef.current?.click()}><Upload size={17}/> Галерия</button></div>
    <input ref={galleryRef} hidden type="file" accept="image/*" onChange={e=>{addPhoto(e.target.files?.[0]);e.currentTarget.value=""}}/>
    <input ref={cameraRef} hidden type="file" accept="image/*" capture="environment" onChange={e=>{addPhoto(e.target.files?.[0]);e.currentTarget.value=""}}/>
    <button className="outline full" onClick={analyze} disabled={!photo||busy}><Sparkles size={17}/> {busy?"Разпознавам…":"Разпознай с AI"}</button>
    <label>Име на артикула *</label><input value={form.name||""} onChange={e=>updateForm("name",e.target.value)} placeholder="Например: Розов суичър"/>
    <label>Категория</label><select value={form.category||"Горнища"} onChange={e=>updateForm("category",e.target.value)}>{categories.slice(1).map(c=><option>{c}</option>)}</select>
    <label>Основен цвят</label><input value={form.color||""} onChange={e=>updateForm("color",e.target.value)} placeholder="Розово"/>
    <label>Сезон</label><div className="chips">{seasons.map(s=><button className={(form.season||[]).includes(s)?"chip active":"chip"} onClick={()=>updateForm("season",(form.season||[]).includes(s)?form.season.filter((x:string)=>x!==s):[...(form.season||[]),s])}>{s}</button>)}</div>
    <label>Стил</label><select value={form.style||"Ежедневен"} onChange={e=>updateForm("style",e.target.value)}>{styles.map(s=><option>{s}</option>)}</select>
    <label>Материя / шарка / бележки</label><input value={form.material||""} onChange={e=>updateForm("material",e.target.value)} placeholder="Памук, райе, любима…"/>
    <button className="primary full" onClick={saveItem} disabled={!storageReady}><Check size={17}/> {storageReady?"Запази в гардероба":"Зареждам…"}</button>
   </div></div>}
  {showSettings&&<div className="modal-back" onClick={()=>setShowSettings(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><h2>Настройки</h2><button className="iconbtn" onClick={()=>setShowSettings(false)}><X/></button></div>
    <p className="sub">Връзка към AI сървъра</p><label>Адрес на сървъра</label><input value={apiUrl} onChange={e=>setApiUrl(e.target.value)} placeholder="https://your-server.example.com"/><button className="primary full" onClick={()=>{localStorage.setItem("mystyle-api",apiUrl);setShowSettings(false);setMessage("Настройките са запазени.")}}>Запази адреса</button>
    <div className="divider"/><h3>Архив и поверителност</h3><p className="sub">Гардеробът се съхранява локално на това устройство. Прави резервно копие редовно.</p><button className="outline full" onClick={exportData}><Download size={17}/> Експортирай архив</button><label className="outline full upload-label"><Upload size={17}/> Възстанови архив<input type="file" accept="application/json" onChange={e=>importData(e.target.files?.[0])}/></label><button className="outline full" onClick={()=>{setItems(p=>p.map(x=>({...x,archived:false})));setShowSettings(false);setTab("wardrobe")}}><Archive size={17}/> Покажи архивираните</button>
    <p className="hint"><Info size={14}/> Не въвеждай лични данни. Снимките се пазят в браузъра на устройството. AI анализът изпраща избраната снимка към конфигурирания сървър.</p>
   </div></div>}
 </div>
}
export default App;
