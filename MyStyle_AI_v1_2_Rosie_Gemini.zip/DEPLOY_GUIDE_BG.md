# MyStyle AI 1.2 – кратко ръководство за обновяване

Запазваме Netlify адреса: https://legendary-sawine-ef6877.netlify.app/

## 1. Резервно копие
Преди обновяване отвори старата версия на приложението → Настройки → Експортирай архив. Запази JSON файла. Не изчиствай Safari website data и не деинсталирай PWA.

## 2. GitHub и Netlify
1. Разархивирай ZIP файла.
2. Качи съдържанието на папката `mystyle-work` в основната директория на GitHub repository-то, което е свързано с Netlify. Ако не си сигурен кое е repository-то, Netlify → Site configuration → Build & deploy → Continuous deployment ще го покаже.
3. Не качвай папката `node_modules` (ако се появи след npm install); в ZIP няма зависимости.
4. Netlify настройки: Base directory празно; Build command `npm run build`; Publish directory `dist`.
5. Netlify → Deploys → Trigger deploy → Clear cache and deploy site.

## 3. Render – Gemini AI сървър
1. Отвори Render Dashboard и избери съществуващия Node service `mystyle-ai-api` (или създай Blueprint от repository-то, ако още няма услуга).
2. Root directory: `server`; Build command: `npm install`; Start command: `npm start`.
3. Environment variables:
   - `GEMINI_API_KEY` = ключът от Google AI Studio (secret)
   - `GEMINI_MODEL` = `gemini-2.5-flash`
   - `FRONTEND_ORIGIN` = `https://legendary-sawine-ef6877.netlify.app`
4. Изтрий/не използвай старите `OPENAI_API_KEY` и `OPENAI_MODEL` променливи.
5. Deploy service.
6. Провери `https://ТВОЯТ-RENDER-АДРЕС/api/health`. Трябва да видиш `ok:true`, `aiConfigured:true`, `provider:"Google Gemini"`.

Ако Render вече е свързан към repository-то и използва `render.yaml`, той може да обнови конфигурацията автоматично. Увери се, че `GEMINI_API_KEY` е зададен като secret.

## 4. Свързване в приложението
На iPhone отвори Netlify адреса → Настройки → Адрес на сървъра. Постави само базовия Render адрес, например `https://mystyle-ai-api.onrender.com` (използвай реалния адрес, който Render показва), без `/api/health`.

## 5. Проверка
- Избери Добави дреха → Камера или Галерия.
- Запази пробна дреха.
- Натисни Разпознай с AI.
- Създай три визии и провери блока „Малко допълнение от Роузи“.
- Затвори и отвори приложението, провери дали дрехата е останала.

## Важно за ключа и безплатния план
Не поставяй Gemini ключа в Netlify frontend, GitHub файловете или чата. Той трябва да бъде само в Render Environment Variables. Безплатното ниво на Gemini може да използва съдържанието за подобряване на услугите си и човешки преглед съгласно условията на Google; изпращайте само снимки на дрехи, без хора и лични данни.

Безплатният Render web service може да заспива при неактивност, затова първата заявка след пауза може да се зарежда по-бавно.
